jQuery(document).ready(function($) {
  $('#slider').flexslider({
    directionNav: false,
    keyboardNav: false
  });
});